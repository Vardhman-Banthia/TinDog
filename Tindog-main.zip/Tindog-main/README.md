TinDog Starting Files(It's not complete still in process)

Feel free to clone the code
You can have a look around on Tindog by visiting here:https://amritchaubey.github.io/Tindog/
